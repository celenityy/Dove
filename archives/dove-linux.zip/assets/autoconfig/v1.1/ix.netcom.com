<clientConfig version="1.1">
  <emailProvider id="earthlink.net">
    <domain>earthlink.net</domain>
    <domain>mindspring.com</domain>
    <domain>ix.netcom.com</domain>
    <!-- many other domains, via MX earthlink.net -->
    <displayName>EarthLink</displayName>
    <displayShortName>EarthLink</displayShortName>
    <incomingServer type="imap">
      <hostname>imap.earthlink.net</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-encrypted</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.earthlink.net</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-encrypted</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtpauth.earthlink.net</hostname>
      <port>587</port>
      <socketType>STARTTLS</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
    <documentation url="https://help.earthlink.net/portal/en/kb/articles/email-server-settings"/>
  </emailProvider>
</clientConfig>
