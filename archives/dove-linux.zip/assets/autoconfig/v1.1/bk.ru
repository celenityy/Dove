<clientConfig version="1.1">
  <emailProvider id="mail.ru">
    <domain>mail.ru</domain>
    <domain>inbox.ru</domain>
    <domain>list.ru</domain>
    <domain>bk.ru</domain>
    <domain>corp.mail.ru</domain>

    <displayName>mail.ru</displayName>
    <displayShortName>mail.ru</displayShortName>

    <incomingServer type="imap">
      <hostname>imap.mail.ru</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="imap">
      <hostname>imap.mail.ru</hostname>
      <port>143</port>
      <socketType>STARTTLS</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.mail.ru</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.mail.ru</hostname>
      <port>110</port>
      <socketType>STARTTLS</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.mail.ru</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.mail.ru</hostname>
      <port>587</port>
      <socketType>STARTTLS</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </outgoingServer>

    <documentation url="http://help.mail.ru/mail-help/mailer/mt">
      <descr lang="en">IMAP, POP, Thunderbird, with screenshots</descr>
    </documentation>
  </emailProvider>

  <oAuth2>
    <issuer>o2.mail.ru</issuer>
    <scope>mail.imap</scope>
    <authURL>https://o2.mail.ru/login</authURL>
    <tokenURL>https://o2.mail.ru/token</tokenURL>
  </oAuth2>

</clientConfig>
