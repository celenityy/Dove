<clientConfig version="1.1">
  <emailProvider id="att.net">
    <domain>ameritech.net</domain>
    <domain>att.net</domain>
    <domain>bellsouth.net</domain>
    <domain>currently.com</domain>
    <domain>flash.net</domain>
    <domain>nvbell.net</domain>
    <domain>pacbell.net</domain>
    <domain>prodigy.net</domain>
    <domain>sbcglobal.net</domain>
    <domain>snet.net</domain>
    <domain>swbell.net</domain>
    <domain>wans.net</domain>
    <displayName>AT&amp;T</displayName>
    <displayShortName>AT&amp;T</displayShortName>
    <incomingServer type="imap">
      <hostname>imap.mail.att.net</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>inbound.att.net</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>outbound.att.net</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.mail.att.net</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>OAuth2</authentication>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
    <documentation url="https://www.att.com/support/article/email-support/KM1010523/">
      <descr lang="en">Configure IMAP and POP3 for att, sbcglobal, swbell etc.</descr>
    </documentation>
  </emailProvider>
</clientConfig>
