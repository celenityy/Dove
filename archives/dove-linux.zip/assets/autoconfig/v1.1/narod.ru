<clientConfig version="1.1">
  <emailProvider id="yandex.ru">
    <domain>yandex.ru</domain>
    <domain>yandex.com</domain>
    <domain>yandex.net</domain>
    <domain>yandex.by</domain>
    <domain>yandex.kz</domain>
    <domain>yandex.ua</domain>
    <domain>ya.ru</domain>
    <domain>narod.ru</domain>

    <displayName>Yandex Mail</displayName>
    <displayShortName>Yandex</displayShortName>

    <incomingServer type="imap">
      <hostname>imap.yandex.com</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.yandex.com</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.yandex.com</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
  </emailProvider>

  <oAuth2>
    <issuer>oauth.yandex.com</issuer>
    <scope>mail:imap_full mail:smtp</scope>
    <authURL>https://oauth.yandex.com/authorize</authURL>
    <tokenURL>https://oauth.yandex.com/token</tokenURL>
  </oAuth2>

  <enable visiturl="http://mail.yandex.ru/neo/setup_client">
    <instruction>Check 'Enable IMAP' on Yandex.Mail setup page</instruction>
  </enable>
</clientConfig>
