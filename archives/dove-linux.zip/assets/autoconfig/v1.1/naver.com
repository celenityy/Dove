<clientConfig version="1.1">
  <emailProvider id="naver.com">
    <domain>naver.com</domain>
    <displayName>Naver</displayName>
    <displayShortName>Naver</displayShortName>
    <incomingServer type="imap">
      <hostname>imap.naver.com</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.naver.com</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.naver.com</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-encrypted</authentication>
    </outgoingServer>
    <documentation url="https://help.naver.com/service/30029/contents/21342?osType=PC&amp;lang=ko"/>
  </emailProvider>
</clientConfig>
